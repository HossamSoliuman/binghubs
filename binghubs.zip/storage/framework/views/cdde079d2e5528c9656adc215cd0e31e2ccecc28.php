<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">CSV Filters</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('files.filter', ['file' => $file->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="states">States (comma-separated):</label>
                        <input type="text" name="states" class="form-control" id="states" placeholder="e.g., TX,MD,FL">
                    </div>
                    <div class="form-group">
                        <label for="dnc">DNC (Y/N/All):</label>
                        <input type="text" name="dnc" class="form-control" id="dnc" placeholder="e.g., Y, N, All">
                    </div>
                    <div class="form-group">
                        <label for="min_age">Minimum Age:</label>
                        <input type="number" name="min_age" class="form-control" id="min_age" placeholder="e.g., 18">
                    </div>
                    <div class="form-group">
                        <label for="max_age">Maximum Age:</label>
                        <input type="number" name="max_age" class="form-control" id="max_age" placeholder="e.g., 65">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Apply Filters">
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\binghubs-test\resources\views/files/fillter.blade.php ENDPATH**/ ?>