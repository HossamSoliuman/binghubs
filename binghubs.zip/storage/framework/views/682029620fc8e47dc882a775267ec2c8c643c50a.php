
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center mt-5">
            <div class="col-md-11">
                <h1>Tables</h1>
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
                    Create a new table
                </button>

                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
                    role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">New Table</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('tables.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Table Name"
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <textarea name="description" class="form-control" placeholder="Table Description" required></textarea>
                                    </div>
                                    <div id="fields-container">
                                        <div class="field-row">
                                            <div class="form-row mb-1">
                                                <div class="col">
                                                    <input type="text" name="fields[]" class="form-control"
                                                        placeholder="Field Name" required>
                                                </div>
                                                <div class="col">
                                                    <select name="field_types[]" class="form-control" required>
                                                        <option value="string">String</option>
                                                        <option value="text">Text</option>
                                                        <option value="int">Integer</option>
                                                    </select>
                                                </div>
                                                <div class="col">
                                                    <select name="field_indexed[]" class="form-control" required>
                                                        <option value="default">Default</option>
                                                        <option value="indexed">Indexed</option>
                                                    </select>
                                                </div>
                                                <div class="col">
                                                    <button type="button"
                                                        class="btn btn-danger remove-field">Remove</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-success" id="add-field">Add Field</button>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

                <table class="table">
                    <thead>
                        <tr>
                            <th>Table Name</th>
                            <th>Description</th>
                            <th>Number of records</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($table->name); ?></td>
                                <td><?php echo e($table->description); ?></td>
                                <td>
                                    <?php echo e($table->record_count); ?>

                                </td>
                              
                                <td class="d-flex">
                                    <form action="<?php echo e(route('tables.duplicates', ['table' => $table->id])); ?>" method="get" class="mr3">
                                        <input class="btn btn-primary mr-2" type="submit" value="Remove Duplicates">
                                    </form>
                                    <form action="<?php echo e(route('tables.destroy', ['table' => $table->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('add-field').addEventListener('click', function() {
            const fieldsContainer = document.getElementById('fields-container');
            const fieldRow = document.querySelector('.field-row').cloneNode(true);
            fieldsContainer.appendChild(fieldRow);
        });

        document.addEventListener('click', function(event) {
            if (event.target && event.target.classList.contains('remove-field')) {
                event.target.closest('.field-row').remove();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\binghubs-test\resources\views/tables/index.blade.php ENDPATH**/ ?>