

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center mt-5">
            <?php if(session('success')): ?>
                <div id="alert" class="alert alert-success alert-dismissible fixed-top fade show mx-auto" role="alert"
                    style="max-width: 500px;">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <script>
                    setTimeout(function() {
                        $('#alert').alert('close');
                    }, 2000);
                </script>
            <?php endif; ?>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header">Upload CSV File</div>
                    <div class="card-body">
                        <form action="<?php echo e(url('/match-csv')); ?>" method="POST" enctype="multipart/form-data"
                            id="upload-form">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="table" class="form-label">Select Database Table</label>
                                <select name="table" class="form-select" id="table" required>
                                    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($table->name); ?>"><?php echo e($table->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-4">
                                <p class="dropzone-text">Drag & drop your CSV file here or click to browse</p>
                                <input name="file" type="file" class="dropzone" id="file" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Match CSV</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <div class="card shadow">
                    <div class="card-header">Upload CSV File</div>
                    <div class="card-body">
                        <form action="<?php echo e(url('/upload')); ?>" method="POST" enctype="multipart/form-data" id="upload-form">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="table" class="form-label">Select Database Table</label>
                                <select name="table" class="form-select" id="table" required>
                                    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($table->name); ?>"><?php echo e($table->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-4">
                                <p class="dropzone-text">Drag & drop your CSV file here or click to browse</p>
                                <input name="file" type="file" class="dropzone" id="file" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Upload into database</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->

        <div class="row justify-content-center mt-4">
            <div class="col-md-11">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Input File</th>
                            <th scope="col">Output File</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(basename($file->input_file)); ?></td>
                                <td><?php echo e(basename($file->output_file)); ?></td>

                                <td class="d-flex">
                                    <a href="<?php echo e(url($file->output_file)); ?>" download class="btn btn-info mr-1">Download</a>
                                    
                                </button>
                                    <form action="<?php echo e(route('files.destroy', ['file' => $file->id])); ?>" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger ml-2">Delete</button>
                                    </form>

                                 
                                </td>
                            </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($files->links()); ?>

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\binghubs\resources\views/files/upload.blade.php ENDPATH**/ ?>