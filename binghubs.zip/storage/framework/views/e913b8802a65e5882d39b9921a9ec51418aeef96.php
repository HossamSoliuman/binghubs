
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center mt-4">
        <div class="col-md-11">
            <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target="#exampleModal">
                New Extract
            </button>
            
            <?php echo $__env->make('extractions.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Extraction from type</th>
                        <th scope="col">Extraction from file</th>
                        <th scope="col">Output File</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $extractions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extraction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($extraction->extracted_from_type); ?></td>
                            <td><?php echo e(basename($extraction->extracted_from)); ?></td>
                            <td><?php echo e(basename($extraction->extraction_result)); ?></td>

                            <td class="d-flex">
                                <a href="<?php echo e(url($extraction->extraction_result)); ?>" download
                                    class="btn btn-info mr-1">Download</a>
                                <form action="<?php echo e(route('extractions.destroy', ['extraction' => $extraction->id])); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger ml-2">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // JavaScript to show/hide the appropriate dropdown or file upload input
        const extractFromDropdown = document.getElementById('extract_from');
        const tableDropdown = document.getElementById('table-dropdown');
        const fileDropdown = document.getElementById('file-dropdown');
        const uploadFile = document.getElementById('upload-file');

        extractFromDropdown.addEventListener('change', function() {
            const selectedValue = extractFromDropdown.value;

            if (selectedValue === 'table') {
                tableDropdown.style.display = 'block';
                fileDropdown.style.display = 'none';
                uploadFile.style.display = 'none';
            } else if (selectedValue === 'existing_file') {
                tableDropdown.style.display = 'none';
                fileDropdown.style.display = 'block';
                uploadFile.style.display = 'none';
            } else if (selectedValue === 'uploaded_file') {
                tableDropdown.style.display = 'none';
                fileDropdown.style.display = 'none';
                uploadFile.style.display = 'block';
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\binghubs-test\resources\views/extractions/index.blade.php ENDPATH**/ ?>