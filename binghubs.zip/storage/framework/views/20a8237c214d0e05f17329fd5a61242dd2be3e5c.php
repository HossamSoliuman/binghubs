<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link btn btn-secondary btn-block mb-2" href="<?php echo e(route('index')); ?>">
                    Home
                </a>
                <a class="nav-link btn btn-secondary btn-block mb-2" href="<?php echo e(route('tables.index')); ?>">
                    Tables
                </a>
                <a class="nav-link btn btn-secondary btn-block mb-2" href="<?php echo e(route('extractions.index')); ?>">
                    Extraction
                </a>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="nav-link btn btn-danger btn-block mb-2" >
                        Logout
                    </button>
                    </a>
                
                </form>
            </li>

        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\binghubs\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>