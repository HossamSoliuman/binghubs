<nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a class="nav-link btn btn-secondary btn-block mb-2" href="<?php echo e(route('index')); ?>">
                    Home
                </a>
                <a class="nav-link btn btn-secondary btn-block mb-2" href="<?php echo e(route('tables.index')); ?>">
                    Tables
                </a>
                <a class="nav-link btn btn-secondary btn-block mb-2" href="<?php echo e(route('extractions.index')); ?>">
                    Extraction
                </a>
            </li>

        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\binghubs-test\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>